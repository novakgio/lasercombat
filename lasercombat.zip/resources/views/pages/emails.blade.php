<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@lang("auth.Sign Up Confirmation")</title>
</head>
<body>
    <h2>{{$about}}</h2>

   

    <p>
        {{$text}}
    </p>
   

    
</body>
</html>