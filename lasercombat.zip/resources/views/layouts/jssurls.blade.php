<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
<script src="{{asset('public/js/jquery.waypoints.min.js')}}"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.9.1/jquery-ui.min.js"></script>
<script type="text/javascript" src="{{asset('public/js/scrolloverflow.js')}}"></script>
<script type="text/javascript" src="{{asset('public/js/jquery.fullPage.js')}}"></script>
<script>


 $('#fullpage').fullpage({
                    anchors: ['firstPage', 'secondPage', '3rdPage','4thPage'],
                    scrollBar: true
                });


                </script>

<script type="text/javascript" src="{{asset('public/js/particles.js')}}"></script>
<script type="text/javascript" src="{{asset('public/js/app.js')}}"></script>
<script type="text/javascript" src="{{asset('public/js/sweetalert.min.js')}}"></script>
<script src="{{asset('public/js/js.js')}}"></script>