<link rel="stylesheet" type="text/css" href="{{asset('public/css/ionicons.min.css')}}">
<link rel="stylesheet" href="{{asset('public/css/loading.css')}}">
<link rel="stylesheet" href="{{asset('public/css/grid.css')}}">
<link rel="stylesheet" href="{{asset('public/css/overlay.css')}}">
<link rel="stylesheet" href="{{asset('public/css/particles.css')}}">
<link rel="stylesheet" href="{{asset('public/css/style.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('public/css/jquery.fullPage.css')}}" />

<link rel="stylesheet" type="text/css" href="{{asset('public/css/sweetalert.css')}}" />
<meta name="csrf-token" content="{{ csrf_token() }}">