<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/ionicons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/loading.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/grid.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/overlay.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/particles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/jquery.fullPage.css')); ?>" />

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/sweetalert.css')); ?>" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">