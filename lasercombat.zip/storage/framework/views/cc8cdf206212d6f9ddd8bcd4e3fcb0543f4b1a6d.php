
<?php  $i=0; ?>
<?php  $previous_time=0; $headerDiv = false; ?>
<?php foreach($orders as $order): ?>
    
    <?php if($i==0 && $headerDiv==false): ?>
        <div class="col span-1-of-12 one-hour-distance">
        <div class="row one-hour-line">
    <?php endif; ?>

    
    <?php 
    

    if($previous_time==$order->time){
            $headerDiv=true;
            continue;
    }
    else{
            $i++;
            $headerDiv=false;
    }
    



    $previous_time = $order->time;


    $state="";
    if($order->active==null) $state="free";
    else if($order->active==1) $state="bought";
    else $state="reserved";
      

     ?>
    <div class="col span-1-of-6 ten-minute-distance <?php echo e($state); ?>-ten-minute">
        <div class="popup-time">
            <p><?php echo e($state); ?></p>
            <p><?php echo e($order->time); ?></p>
        </div>
    </div>
    

     <?php if($i==6): ?>   
         </div> 
         </div>
    <?php endif; ?>
    <?php if($i==6) $i=0;?>
    

<?php endforeach; ?>