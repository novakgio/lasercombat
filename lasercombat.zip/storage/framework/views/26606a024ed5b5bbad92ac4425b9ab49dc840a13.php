<i class="ion-close-round close-inner-popup" id="close-ticket"></i>
                    <div class="row ticket-line">
                        <span class="ticket-title">Date:</span>
                        <span class="ticket-value"><?php echo e($date); ?></span>
                    </div>
                    <div class="row ticket-line">
                        <span class="ticket-title">Start Time:</span>
                        <span class="ticket-value"><?php echo e($start_time); ?></span>
                    </div>
                    <div class="row ticket-line">
                        <span class="ticket-title">End Time:</span>
                        <span class="ticket-value"><?php echo e($end_time); ?></span>
                    </div>

                    <?php 
                   
                    $state= ($active==1) ? "ნაყიდი":"დაჯავშნილი";
                     ?>
                    <div class="row ticket-line">
                        <span class="ticket-title">Type:</span>
                        <span class="ticket-value"><?php echo e($state); ?></span>
                    </div>
                    <div class="row ticket-line">
                        <span class="ticket-title">Number Of Players:</span>
                        <span class="ticket-value"><?php echo e($people); ?></span>
                    </div>