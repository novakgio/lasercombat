<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class scheduleOrder extends Model
{
    //

    protected $table = "order_schedule";
    public $timestamps=false;
}
